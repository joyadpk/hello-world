package com.mphasis.service;

import java.util.List;

import com.mphasis.model.Notification;

public interface NotificationService {

Notification findByUsername(String username);
	
	List<Notification> findAll();
	
	public void save(Notification n);
}
