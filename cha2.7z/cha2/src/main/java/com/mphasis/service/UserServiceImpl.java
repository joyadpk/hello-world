package com.mphasis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.dao.UserDao;
import com.mphasis.model.User;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{
 
    @Autowired
    private UserDao dao;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
 
    public User findById(int id) {
        return dao.findById(id);
    }
 
    public User findByUsername(String username) {
        return dao.findByUsername(username);
    }
    
    public void save(User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        dao.save(user);
    }

	@Override
	public List<User> findAll() {

		return dao.findAll();
	}

	@Override
	public void blockUser(Integer id) {
	
		dao.blockUser(id);
		
	}

	@Override
	public void activateUser(Integer id) {
		
		dao.activateUser(id);
		
	}

	@Override
	public void deleteUser(Integer id) {
		
		dao.deleteUser(id);
	}
 
}