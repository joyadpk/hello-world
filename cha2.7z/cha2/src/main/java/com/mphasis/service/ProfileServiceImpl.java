package com.mphasis.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.dao.ProfileDao;
import com.mphasis.model.Profile;

@Service("userProfileService")
@Transactional
public class ProfileServiceImpl implements ProfileService {
    
   @Autowired
   ProfileDao dao;
    
   public List<Profile> findAll() {
       return dao.findAll();
   }

   public Profile findByType(String type){
       return dao.findByType(type);
   }

   public Profile findById(int id) {
       return dao.findById(id);
   }
   
}