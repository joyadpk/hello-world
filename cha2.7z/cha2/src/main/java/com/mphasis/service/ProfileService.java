package com.mphasis.service;

import java.util.List;

import com.mphasis.model.Profile;

public interface ProfileService {

	List<Profile> findAll();
    
	Profile findByType(String type);
     
	Profile findById(int id);
	
	
}
