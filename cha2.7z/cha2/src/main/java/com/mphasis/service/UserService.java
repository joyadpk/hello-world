package com.mphasis.service;

import java.util.List;

import com.mphasis.model.User;

public interface UserService {
	 
    User findById(int id);
     
    User findByUsername(String username);
    
    public void save(User user);
    
    List<User> findAll();
    
    void blockUser(Integer id);
    
    void activateUser(Integer id);

    void deleteUser(Integer id);
     
}