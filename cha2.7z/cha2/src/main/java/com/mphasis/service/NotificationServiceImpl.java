package com.mphasis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.dao.NotificationDao;

import com.mphasis.model.Notification;

@Service("notificationService")
@Transactional
public class NotificationServiceImpl implements NotificationService {
	
	 @Autowired
	    private NotificationDao dao;

	@Override
	public Notification findByUsername(String username) {
	
		return dao.findByUsername(username);
	}

	@Override
	public List<Notification> findAll() {
	
		return dao.findAll();
	
	}

	@Override
	public void save(Notification n) {
		dao.save(n);
		
	}

}
