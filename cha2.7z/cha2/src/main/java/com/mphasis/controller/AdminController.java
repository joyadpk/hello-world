package com.mphasis.controller;


import java.util.Arrays;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mphasis.model.Notification;
import com.mphasis.model.Profile;
import com.mphasis.model.State;
import com.mphasis.model.User;
import com.mphasis.service.NotificationService;
import com.mphasis.service.ProfileService;
import com.mphasis.service.UserService;

@Controller
@Scope("session")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private UserService us;
	
	@Autowired
	private ProfileService ps;
	
	@Autowired
	private NotificationService  ns;

	// Login Page with GET Request
	 @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public String adminLogin()
	    {	
	        return "/admin/login";
	    }
	 
	 
	 @RequestMapping(value = "/login_success", method = RequestMethod.GET)
	    public String adminHome(ModelMap model, HttpServletRequest r )
	    {
		 
		 // Session Code
		 
		 HttpSession s = r.getSession();
		 
		 s.setAttribute("u", getPrincipal());
		 
		 System.out.println(getPrincipal());
		 
		 model.addAttribute("u", getPrincipal());
		 model.addAttribute("userlist",us.findAll());
		 
	        return "/admin/admin_home";
	    }
	 
	 
	 
	 @RequestMapping(value = "/admin_home", method = RequestMethod.GET)
	    public String admin_Home(ModelMap model, HttpServletRequest r)
	    {	
		 HttpSession s = r.getSession();
		 
		 s.setAttribute("u", getPrincipal());
		 
		 System.out.println(getPrincipal());
		 model.addAttribute("userlist",us.findAll());
		 model.addAttribute("u", getPrincipal());
		 
	        return "/admin/admin_home";
	    }
	 
	 
	 
	 
	
	 // Logout Page for admin 
	    @RequestMapping(value="/logout", method = RequestMethod.GET)
	    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
	        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	        if (auth != null){    
	            new SecurityContextLogoutHandler().logout(request, response, auth);
	        }
	        return "redirect:/admin/login?logout";
	    }
	    
	    
	       
	    @RequestMapping(value = "/addnewuser", method = RequestMethod.GET)
	    public String newRegistration(ModelMap model) {
	        User user = new User();
	        model.addAttribute("user", user);
	        return "/admin/newuser";
	    }
	 
	    
	     // This method will be called on form submission, handling POST request It
	     // also validates the user input
	     
	    @RequestMapping(value = "/addnewuser", method = RequestMethod.POST)
	    public String saveRegistration(@Valid User user,BindingResult result, ModelMap model) {
	 
	        if (result.hasErrors()) {
	            System.out.println("There are errors");
	            return "/admin/newuser";
	        }
	        us.save(user);
	        
	        if(user.getUserProfiles()!=null){
	            for(Profile profile : user.getUserProfiles()){
	                System.out.println("Profile : "+ profile.getType());
	            }
	        }
	         
	        
	        
	        // Notification Code
	        Notification n = new Notification();
	        n.setUsername(user.getUsername());
	        
	        String message = user.getUsername()+" Has Been Added By Admin Today at "+new java.util.Date().toString();
	        n.setMessage(message);
	        ns.save(n);
	        model.addAttribute("blink",1); 
	        
	        
	        
	        model.addAttribute("added", "User " + user.getUsername() + " has been registered successfully");
	        model.addAttribute("userlist",us.findAll());
	        return "/admin/admin_home";
	    }
	    
	    // Block the User
	    @RequestMapping(value = "/block-{id}", method = RequestMethod.GET)
	    public String block(@PathVariable Integer id, ModelMap m)
	    {
	    	us.blockUser(id);
	    	
	    	 // Notification Code
	        Notification n = new Notification();
	        n.setUsername(us.findById(id).getUsername());
	        
	        String message = us.findById(id).getUsername()+" Has Been Blocked By Admin Today at "+new java.util.Date().toString();
	        n.setMessage(message);
	        ns.save(n);
	        m.addAttribute("blink",1); 
	    	
	    	
	    	
	    	m.addAttribute("userlist",us.findAll());
	    	return "/admin/admin_home";
	    }
	    
	 // Activate the User
	    @RequestMapping(value = "/activate-{id}", method = RequestMethod.GET)
	    public String activate(@PathVariable Integer id, ModelMap m)
	    {
	    	us.activateUser(id);
	    	
	    	
	    	
	    	 // Notification Code
	        Notification n = new Notification();
	        n.setUsername(us.findById(id).getUsername());
	        
	        String message = us.findById(id).getUsername()+" Has Been Activated By Admin Today at "+new java.util.Date().toString();
	        n.setMessage(message);
	        ns.save(n);
	        m.addAttribute("blink",1);
	    	
	    	
	    	
	    	
	    	
	    	m.addAttribute("userlist",us.findAll());
	    	return "/admin/admin_home";
	    }
	    
	    
	 // Delete the User
	    @RequestMapping(value = "/delete-{id}", method = RequestMethod.GET)
	    public String delete(@PathVariable Integer id, ModelMap m)
	    {
	    	String name = us.findById(id).getUsername();
	    	
	    	us.deleteUser(id);
	    	
	    	
	    	 // Notification Code
	        Notification n = new Notification();
	        n.setUsername(name);
	        
	        String message = name+" Has Been Deleted By Admin Today at "+new java.util.Date().toString();
	        n.setMessage(message);
	        ns.save(n);
	        m.addAttribute("blink",1);
	    	
	    	m.addAttribute("userlist",us.findAll());
	    	return "/admin/admin_home";
	    }
	    
	    
	    
// Notifications Page
	    
	    @RequestMapping(value = "/notifications", method = RequestMethod.GET)
	    public String notific(Model m)
	    {
	    	return "/admin/notification";
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	  private String getPrincipal(){
	        String userName = null;
	        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 
	        if (principal instanceof UserDetails) {
	            userName = ((UserDetails)principal).getUsername();
	        } else {
	            userName = null;
	        }
	        return userName;
	    }
	     
	     
	// User Database Sent to JSP
	  
	/*  @ModelAttribute("userlist")
	  public List<User> all()
	  { 
		 return us.findAll();
	  }*/
	  
	  
	  @ModelAttribute("notifications")
	    public List<Notification> notific() {
	        return ns.findAll();
	    }
	  
	  
	  
	     
	    @ModelAttribute("roles")
	    public List<Profile> initializeProfiles() {
	        return ps.findAll();
	    }
	    
	    @ModelAttribute("states")
	    public List<State> states() {

	    	List<State> s = Arrays.asList(State.class.getEnumConstants());
	    	
	    	return s;
	    }
	    
	    
	    
}
