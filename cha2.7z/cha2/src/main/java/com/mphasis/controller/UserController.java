package com.mphasis.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.model.DefectInfo;
import com.mphasis.model.Notification;
import com.mphasis.service.NotificationService;

@Controller
@Scope("session")
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private NotificationService  ns;

	 @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public String userLogin(ModelMap model)
	    {	
	        return "/user/login";
	    }
	
	 
	 @RequestMapping(value = "/login_success", method = RequestMethod.GET)
	    public String userHome(ModelMap model, HttpServletRequest r)
	    {
		 
		 HttpSession s = r.getSession();
		 
		 s.setAttribute("u", getPrincipal());
		 
		 System.out.println(getPrincipal());
		 
		 model.addAttribute("u", getPrincipal());
		 
		
	        return "/user/user_home";
	    }
	 
	 
	 
	 @RequestMapping(value = "/user_home", method = RequestMethod.GET)
	    public String user_Home(ModelMap model, HttpServletRequest r)
	    {	
		 HttpSession s = r.getSession();
		 
		 s.setAttribute("u", getPrincipal());
		 
		 System.out.println(getPrincipal());

		 model.addAttribute("u", getPrincipal());
		 
	        return "/user/user_home";
	    }
	 
	 
	 
	 
	 
	// Logout Page for user
	    @RequestMapping(value="/logout", method = RequestMethod.GET)
	    public String userLogoutPage (HttpServletRequest request, HttpServletResponse response) {
	        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	        if (auth != null){    
	            new SecurityContextLogoutHandler().logout(request, response, auth);
	        }
	        return "redirect:/user/login?logout";
	    }
	
	    
	    
	    @RequestMapping(value = "/create", method = RequestMethod.GET)
	    public String create(ModelMap m)
	    {	m.addAttribute("defectinfo", new DefectInfo());
	    	m.addAttribute("date", new java.util.Date().toString());
	        return "/user/create";
	    }
	    
	    
	    @RequestMapping(value = "/create", method = RequestMethod.POST)
		public ModelAndView formHandling(@ModelAttribute DefectInfo defectinfo, @RequestParam("files") MultipartFile files) throws IOException, NullPointerException
	    {	
			if (!files.getOriginalFilename().isEmpty()) 
			{
		         BufferedOutputStream outputStream = new BufferedOutputStream(
		               new FileOutputStream(
		                     new File("C:/uploadedData/"+files.getOriginalFilename())));
		         outputStream.write(files.getBytes());
		         outputStream.flush();
		         outputStream.close();
			
		         return new ModelAndView("/user/data_upload","message","File Upload Successful !!!"+files.getOriginalFilename());
			}    
			
			else
			{
				return new ModelAndView("/user/data_upload","message","File Upload UnSuccessful !!!");
			}
				
		   
			
		}
	    
	    
	    @RequestMapping(value = "/data_upload", method = RequestMethod.GET)
	    public ModelAndView dataUpload(Model m)
	    {	
	        return new ModelAndView("/user/data_upload", "command", new DefectInfo());
	    }
	    
	    
	    
 // Notifications Page
	    
	    @RequestMapping(value = "/notifications", method = RequestMethod.GET)
	    public String notific(Model m)
	    {
	    	return "/user/notification";
	    }
	    
	    
	    
	    @ModelAttribute("notifications")
	    public List<Notification> notific() {
	        return ns.findAll();
	    }
	    
	    
	    
	    
	    
	    private String getPrincipal(){
	        String userName = null;
	        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 
	        if (principal instanceof UserDetails) {
	            userName = ((UserDetails)principal).getUsername();
	        } else {
	            userName = null;
	        }
	        return userName;
	    }
	    
	    
	    
	    
	    
}
