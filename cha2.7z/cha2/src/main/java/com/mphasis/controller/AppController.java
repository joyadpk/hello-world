package com.mphasis.controller;




import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;










import com.mphasis.model.Message;
import com.mphasis.model.OutputMessage;
import com.mphasis.model.User;


@Controller
public class AppController {
  
	
	@RequestMapping(value = {" /" , "/home"} , method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView home()
	{
		return new ModelAndView("home","command",new User());
	}
	
	    
	 // Access Denied Page
	    @RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
	    public String accessDenied(ModelMap m)
	    {	
	    	m.addAttribute("user", getPrincipal());
	        return "accessDenied";
	    }
	    
	    
	    
	    // method to get username
	    private String getPrincipal(){
	        String userName = null;
	        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 
	        if (principal instanceof UserDetails) {
	            userName = ((UserDetails)principal).getUsername();
	        } else {
	            userName = null;
	        }
	        return userName;
	    }

	    
	    
	    // Chat app impl
	    
	    @MessageMapping("/chat")
	    @SendToUser(value = "/'+getPrincipal()+' ", broadcast=false)
	    public OutputMessage send(Message message) throws Exception {
	        String time = new SimpleDateFormat("HH:mm").format(new Date());
	        return new OutputMessage(message.getFrom(), message.getText(), time);
	    } 
	    
	    
	    @RequestMapping(value = "/chat", method = RequestMethod.GET)
	    public String chat(ModelMap m)
	    {	
	    
	        return "chat";
	    }
	    
}
