package com.mphasis.dao;

import java.util.List;

import com.mphasis.model.Notification;

public interface NotificationDao {

	Notification findByUsername(String username);
	
	List<Notification> findAll();
	
	public void save(Notification n);
	
	
}
