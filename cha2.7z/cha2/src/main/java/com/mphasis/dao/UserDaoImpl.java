package com.mphasis.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.model.Profile;
import com.mphasis.model.User;

@Repository("userDao")
public class UserDaoImpl extends AbstractDao<Integer, User> implements UserDao {

	
	@Override
	public User findById(int id) {
		 return getByKey(id);
	}

	@Override
	public User findByUsername(String username) {
		
		 Criteria crit = createEntityCriteria();
	        crit.add(Restrictions.eq("username", username));
	        return (User) crit.uniqueResult();
	}

	@Override
	public void save(User user) {
        persist(user);
    }

	@Override
	public List<User> findAll() {
		
		 Criteria crit = createEntityCriteria();
	        crit.addOrder(Order.asc("id"));
	        return (List<User>)crit.list();
	}

	@Override
	public void blockUser(Integer id) {
		
	Query q =	getSession().createSQLQuery("update userlist set state = 'Blocked' where id ="+id);
	
	q.executeUpdate();
	
	}

	@Override
	public void activateUser(Integer id) {
		Query q =	getSession().createSQLQuery("update userlist set state = 'Active' where id ="+id);
		
		q.executeUpdate();
	}

	@Override
	public void deleteUser(Integer id) {
	
		User u1 = findById(id);
		System.out.println(u1.toString());
		delete(u1);
		
	}

	
	
}
