package com.mphasis.dao;

import java.util.List;

import com.mphasis.model.Profile;

public interface ProfileDao {
	
	    List<Profile> findAll();
     
	    Profile findByType(String type);
	     
	    Profile findById(int id);
}
