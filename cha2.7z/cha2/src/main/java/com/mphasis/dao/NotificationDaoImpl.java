package com.mphasis.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.mphasis.model.Notification;

@Repository("notificationDao")
public class NotificationDaoImpl extends AbstractDao<Integer, Notification> implements NotificationDao {

	@Override
	public Notification findByUsername(String username) {
		Criteria crit = createEntityCriteria();
        crit.add(Restrictions.eq("username", username));
        return (Notification) crit.list();
		
	}

	@Override
	public List<Notification> findAll() {
		
		Criteria crit = createEntityCriteria();
        crit.addOrder(Order.desc("id"));
        return (List<Notification>)crit.list();
	}

	@Override
	public void save(Notification n) {
        persist(n);
    }
	
}
