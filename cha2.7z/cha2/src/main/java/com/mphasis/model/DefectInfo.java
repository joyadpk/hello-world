package com.mphasis.model;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class DefectInfo 
{
	private String defect_name;
	
	private String defect_application;
	private String defect_service;
	
	private String defect_date;
	
	private String defect_author;
	private String defect_description;
	
	private List<MultipartFile> files;

	public String getDefect_name() {
		return defect_name;
	}

	public void setDefect_name(String defect_name) {
		this.defect_name = defect_name;
	}

	public String getDefect_application() {
		return defect_application;
	}

	public void setDefect_application(String defect_application) {
		this.defect_application = defect_application;
	}

	public String getDefect_service() {
		return defect_service;
	}

	public void setDefect_service(String defect_service) {
		this.defect_service = defect_service;
	}

	public String getDefect_date() {
		return defect_date;
	}

	public void setDefect_date(String defect_date) {
		this.defect_date = defect_date;
	}

	public String getDefect_author() {
		return defect_author;
	}

	public void setDefect_author(String defect_author) {
		this.defect_author = defect_author;
	}

	public String getDefect_description() {
		return defect_description;
	}

	public void setDefect_description(String defect_description) {
		this.defect_description = defect_description;
	}

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	

}
