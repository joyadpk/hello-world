package com.mphasis.model;

public enum ProfileType {

	USER("USER");
  
     
    String profileType;

	public String getProfileType() {
		return profileType;
	}

	private ProfileType(String profileType) {
		this.profileType = profileType;
	}
 
    
}
