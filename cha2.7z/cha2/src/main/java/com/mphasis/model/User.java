package com.mphasis.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name="userlist")
public class User {
 
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE)
    private int id;
 
    @Column(name="username", unique=true, nullable=false)
    private String username;
     
    @Column(name="password", nullable=false)
    private String password;
         
  
    @Column(name="state", nullable=false)
    private String state=State.ACTIVE.getState();
    
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "userlist_profile", joinColumns = { @JoinColumn(name = "user_id") }, inverseJoinColumns = { @JoinColumn(name = "profile_id") })
    private Set<Profile> userProfiles = new HashSet<Profile>();


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Set<Profile> getUserProfiles() {
		return userProfiles;
	}


	public void setUserProfiles(Set<Profile> userProfiles) {
		this.userProfiles = userProfiles;
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password="
				+ password + ", state=" + state + ", userProfiles="
				+ userProfiles + "]";
	}
      
}
