package com.mphasis.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.mphasis.model.Profile;
import com.mphasis.service.ProfileService;


@Component
public class RoleToUserProfileConverter implements Converter<Object, Profile>{
 
    @Autowired
    ProfileService profileService;
 
    /*
     * Gets UserProfile by Id
     * @see org.springframework.core.convert.converter.Converter#convert(java.lang.Object)
     */
    public Profile convert(Object element) {
        Integer id = Integer.parseInt((String)element);
        Profile profile= profileService.findById(id);
        System.out.println("Profile : "+profile);
        return profile;
    }
     
    /*
     * Gets UserProfile by type
     * @see org.springframework.core.convert.converter.Converter#convert(java.lang.Object)
     */
    /*
    public UserProfile convert(Object element) {
        String type = (String)element;
        UserProfile profile= userProfileService.findByType(type);
        System.out.println("Profile ... : "+profile);
        return profile;
    }
    */
 
}
