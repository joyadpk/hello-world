package com.mphasis.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
// for Spring MVC project, 
@EnableWebMvc
// this annotation is needed

@Configuration
@Import({ WebSocketConfig.class })
@ComponentScan(basePackages = "com.mphasis")
public class SpringConfig extends WebMvcConfigurerAdapter {

	// Spring MVC Changes 
	
	 	@Autowired
	 	RoleToUserProfileConverter roleToUserProfileConverter;
	
	 	@Bean
    	public ViewResolver viewResolver() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setViewClass(JstlView.class);
        viewResolver.setPrefix("/WEB-INF/views/");
        viewResolver.setSuffix(".jsp");
        return viewResolver;
	 	}
     
	 	@Bean
	 	public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasename("messages");
        return messageSource;
	 	}
    
	 	public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	 	}
    
	 	@Bean(name = "multipartResolver")
	 	public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(1024*1024*1024);
        multipartResolver.setMaxInMemorySize(0);
        return multipartResolver;
	 	}
    
	 	// Spring Security Code
    
	 	@Override
	 	public void addViewControllers(ViewControllerRegistry registry) 
	 	{
    	registry.addViewController("/").setViewName("home");
        registry.addViewController("/user/user_home").setViewName("user/user_home");
        registry.addViewController("/admin/admin_home").setViewName("admin/admin_home");
        registry.addViewController("/user/login").setViewName("user/login");
        registry.addViewController("/admin/login").setViewName("admin/login");
	 	}
    
	 	@Override
	 	public void configureViewResolvers(ViewResolverRegistry registry) {
	 	registry.jsp().prefix("/WEB-INF/views/").suffix(".jsp");
	 	}
    
	 	
	 	/*
	 	 * Configure Converter to be used.
	 	 * In our example, we need a converter to convert string values[Roles] to UserProfiles in newUser.jsp
	 	 */
   
    
	 	@Override
	 	public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(roleToUserProfileConverter);
	 	}
    
}