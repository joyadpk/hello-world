package com.mphasis.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@EnableWebSecurity
@Configuration
public class MultiHttpSecurityConfig {
	
	/*@Bean
    public static UserDetailsService userDetailsService() throws Exception 
	{
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        
        manager.createUser(User.withUsername("anand").password("anand").roles("USER").build());
        manager.createUser(User.withUsername("admin").password("admin").roles("ADMIN").build());
        
        return manager;
    }*/
	
	@Autowired
    @Qualifier("customUserDetailsService")
    UserDetailsService userDetailsService;
	
	
	@Autowired
    public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService);
        auth.authenticationProvider(authenticationProvider());
    }
	
	
	 @Bean
	    public PasswordEncoder passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }
	 
	 
	 @Bean
	    public DaoAuthenticationProvider authenticationProvider() {
	        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
	        authenticationProvider.setUserDetailsService(userDetailsService);
	        authenticationProvider.setPasswordEncoder(passwordEncoder());
	        return authenticationProvider;
	    }
	
	
	
	 
	 
	 
	@Configuration
	@Order(1)
	public static class AdminSecurityConfiguration extends WebSecurityConfigurerAdapter 
	{
		
		 @Override
		  public void configure(WebSecurity web) throws Exception {
		    web
		      .ignoring()
		         .antMatchers("/user/resources/**").and()
		         .ignoring().antMatchers("/user/webjars/**"); 
		  }
		
		
		@Override
	    protected void configure(HttpSecurity http) throws Exception 
	    {   
		  http
		  	  .antMatcher("/webjars/**").authorizeRequests().anyRequest().permitAll().and()
		      .antMatcher("/admin/**").authorizeRequests().anyRequest().hasRole("ADMIN")
	          .and()
	          .formLogin().loginPage("/admin/login").permitAll()
	          .defaultSuccessUrl("/admin/login_success",true)
	          .usernameParameter("username").passwordParameter("password")
	          .and()
	          .logout().logoutUrl("/admin/logout").permitAll().and()
	          .exceptionHandling().accessDeniedPage("/Access_Denied")
	          ;
	          
	    }
	}
	
	
	@Configuration
	@Order(2)
	public class UserSecurityConfiguration extends WebSecurityConfigurerAdapter {
		
		@Override
		  public void configure(WebSecurity web) throws Exception {
		    web
		      .ignoring()
		         .antMatchers("/admin/resources/**").and()
		         .ignoring().antMatchers("/admin/webjars/**"); 
		  }
	   
	    @Override
	    protected void configure(HttpSecurity http) throws Exception 
	    { 
	      http
			  .antMatcher("/user/**").authorizeRequests().anyRequest().hasRole("USER")
			  .and().formLogin().loginPage("/user/login").permitAll()
	          .defaultSuccessUrl("/user/login_success")
	          .usernameParameter("username").passwordParameter("password")
	          .and().logout()
	          .logoutUrl("/user/logout").permitAll()
	          .and().exceptionHandling().accessDeniedPage("/Access_Denied");
	    }
	}
	
}
