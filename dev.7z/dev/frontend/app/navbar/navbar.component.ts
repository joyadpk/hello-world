import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../services/security.service';

import { User } from '../user.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss', '../app.component.css']
})
export class NavbarComponent implements OnInit {

  currentUser: User;
  
    constructor(private securityService : SecurityService, public route:Router) { 
  
      this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  
    }
  
  
    ngOnInit() {
  
    }
  
    
    logOut() {
      this.securityService.logOut()
        .subscribe(
          data => {
            this.route.navigate(['/login']);
          },
          error => {
  
          });
    }

}
