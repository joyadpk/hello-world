import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class SearchService {
  constructor(private http: Http) {}

  getAppList(): Observable<any> {
    return this.http.get('api/applist').map(res => res.json());
  }

  getSvcList(): Observable<any> {
    return this.http.get('api/svclist').map(res => res.json());
  }

  getSearchResult(sParam): Observable<any> {
    return this.http.post('api/search', sParam).map(res => res.json());
  }
}
