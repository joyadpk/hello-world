import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { Defect } from '../defect.model';

import 'rxjs/add/operator/toPromise';
import { SecurityService } from './security.service';
import { file } from '../file.model';
import { ResponseContentType } from '@angular/http';




@Injectable()
export class DefectService {

  private baseUrl = 'http://localhost:1122/api/defect';
  
  private headers = new Headers({'Content-Type': 'application/json'});
  
  private user = JSON.parse(localStorage.getItem('currentUser'));

  private header1 = new Headers({'Content-Type': 'application/octet-stream'});

  getHeader()
  {
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    let options = new RequestOptions();
    options.headers=headers;
    return options;
  }


  isLoading = true;

   constructor(private http: Http, private securityService : SecurityService) { }
  
   getDefectById(Id: string): Promise<Defect> {
     return this.http.get(`${this.baseUrl}/findById/${Id}`, this.getHeader())
                     .toPromise()
                     .then(response => response.json() as Defect)
                     .catch(this.handleError);
   }
  
   createNewDefect(d: Defect): Promise<void> {
    const url = `${this.baseUrl}/create`;
     return this.http.post(url, JSON.stringify(d), {headers : this.headers} )
                     .toPromise()
                     .then(() =>null) 
                     .catch(this.handleError);
   }
  
   updateDefect(id : string, d : Defect): Promise<Defect> {
    const url = `${this.baseUrl}/update/${id}`;
     return this.http.put(url, JSON.stringify(d),  {headers : this.headers} )
                     .toPromise()
                     .then(() => d)
                     .catch(this.handleError);
   }

   getAllDefects(): Promise<Defect[]> {
    const url = `${this.baseUrl}/all`;
     return this.http.get(url,this.getHeader() )
                     .toPromise()
                     .then(response => response.json() as Defect[])
                     .catch(this.handleError);
   }

   getLatestDefects(): Promise<Defect[]> {
    const url = `${this.baseUrl}/latest`;
     return this.http.get(url,this.getHeader() )
                     .toPromise()
                     .then(response => response.json() as Defect[])
                     .catch(this.handleError);
   }


   getUploads(id: string): Promise<file> {
     const url = `http://localhost:1122/docs/${id}`;
    return this.http.get(url, this.getHeader())
                    .toPromise()
                    .then(response => response.json() as File)
                    .catch(this.handleError);
  }

  downloadFile(id : string) : void
  {   
    const url = `http://localhost:1122/download/${id}`;
    window.open(url);
   }



   private handleError(error: any): Promise<any> {
    console.error('An error occurred', error); // for demo purposes only
    return Promise.reject(error.message || error);
 }

 /*
   deletePost(postId: number): Promise<void> {
     return this.http.delete(`${this.baseUrl}/${postId}`, this.getHeader() )
                     .toPromise()
                     .then(() => null)
                     .catch(this.handleError);
   }
  

   deleteAll(): Promise<void> {
    return this.http.delete(this.baseUrl,this.getHeader())
                    .toPromise()
                    .then(() => null)
                    .catch(this.handleError);
  }
*/


}
