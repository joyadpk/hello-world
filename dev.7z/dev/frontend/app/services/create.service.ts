import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class CreateService {
  constructor(private http: Http) {}

  createErrDoc(param): Observable<any> {
    return this.http.post('api/create', param).map(res => res.json());
  }
}
