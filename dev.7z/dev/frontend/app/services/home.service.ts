import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class HomeService {
  constructor(private http: Http) {}

  getHome(): Observable<any> {
    return this.http.get('/api/home').map(res => res.json());
  }
}
