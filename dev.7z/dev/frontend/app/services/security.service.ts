import { Injectable } from '@angular/core';

import { Headers, Http, RequestOptions,Response } from '@angular/http';

import { User } from '../user.model';

import 'rxjs/add/operator/map';

@Injectable()
export class SecurityService {

    private baseUrl = 'http://localhost:1122';

    private currentUser : User = null;

    private headers = new Headers({'Content-Type': 'application/json'});

    constructor(private http: Http) {
    }


    isLoggedIn()
    {
        if(this.currentUser == null)
        {
            return false;
        }
        else
        {
            return true;
        }

    }


    authenticate(user : User)
    {
        let headers = new Headers();
        headers.append('Accept', 'application/json')

        var base64Credential: string = btoa( user.username+ ':' + user.password);
        headers.append("Authorization", "Basic " + base64Credential);
     

        let options = new RequestOptions();
        options.headers=headers;

     return this.http.get(`${this.baseUrl}/login`, options)
     .map((response: Response) => {

        // login successful if there's a jwt token in the response
        
        let user = response.json().principal;// the returned user object is a principal object
        
        if (user) {
        
            // store user details  in local storage to keep user logged in between page refreshes
        
          localStorage.setItem('currentUser', JSON.stringify(user));
        }
      });
 
    }


    logOut() {
        // remove user from local storage to log user out
        return this.http.post(`${this.baseUrl}/logout`,{})
          .map((response: Response) => {
            localStorage.removeItem('currentUser');
          });
        }



        signup(user: User): Promise<void> {
            const url = `${this.baseUrl}/signup`;
             return this.http.post(url, JSON.stringify(user), {headers : this.headers} )
                             .toPromise()
                             .then(() =>null) 
                             .catch(this.handleError);
        }


    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
     }

      
}
