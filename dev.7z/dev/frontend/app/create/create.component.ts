import { Component, OnInit } from '@angular/core';

import {Defect} from '../defect.model';
import { Apps } from '../model/app-list';
import { Services } from '../model/service-lists';

import { DefectService } from '../services/defect.service';

import { Router } from '@angular/router';

import { file } from '../file.model';
import { User } from '../user.model';

import { FileUploader, FileUploaderOptions } from 'ng2-file-upload';

import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css', '../app.component.css']
})


export class CreateComponent implements OnInit {
  
  isLoading = true;
  applications = Apps;
  services = Services;
  appDate: Date = new Date();
  model = new Defect();

  

  d_id : string; 
  
  currentUser : User;

  myFiles:string [] = [];


getUrl()
{
  const url : string = "http://localhost:1122/upload/"+this.model.id+"/"+this.currentUser.username;
  return url; 
}


public uploader:FileUploader;

public hasBaseDropZoneOver:boolean = false;

public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
    console.log(e);
  }

  constructor(private defectService: DefectService, private route : Router
  ) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  createDoc() : void {

    this.isLoading =  true;

  //  console.log(this.model.defect_author);
  //  console.log(this.model.id);
  //  console.log(this.getUrl());

    this.createNewDefect();
  }

  createNewDefect() : void {

      this.uploader.uploadAll();
    
      this.defectService.createNewDefect(this.model).then(() => {
      this.isLoading=false;
      this.route.navigate(['home']);
    }); 
    
  }


randomize() : string
{
  let id : string;
  id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15); 
  return id;
}

  ngOnInit() {
    this.isLoading=false;
    
    this.d_id= this.randomize();
    this.model.id = this.d_id;
    this.uploader = new FileUploader({url: this.getUrl() });
    this.model.defect_date = this.appDate.toDateString();
    this.model.defect_author = this.currentUser.username;
  }

 
}
