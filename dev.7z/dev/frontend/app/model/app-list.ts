export class App {
id : number;
name : String;
}

export const Apps : App[] = [
    {id : 1, name : "SHD"},
    {id : 2, name : "PPS"},
    {id : 3, name : "ARD"},
    {id : 4, name : "ACE"},
    {id : 5, name : "EFD"},
    {id : 6, name : "GSA"},
    {id : 7, name : "HLP"},
    {id : 8, name : "SEF"},
    {id : 9, name : "TCC"},
    {id : 10, name : "WSM"} 
]