export class Defect {
  constructor(
    public id : string = '',
    public defect_application: string = '',
    public defect_service: string = '',
    public defect_date : string = '',
    public defect_author: string = '',
    public defect_subject: string = '',
    public defect_resolution: string = '',
  ) {}
}
