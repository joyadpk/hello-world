import { Component, OnInit } from '@angular/core';

import { User } from '../../user.model';
import { SecurityService } from '../../services/security.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  model = new User();

  currentUser : User = null;

  errorMessage : string;

  constructor(private securityService : SecurityService, private route: Router) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
   }

  ngOnInit() 
  {
    this.loginCheck();
  }


  loginCheck()
  {
    if(this.currentUser !=null)
    {
      this.route.navigate(['home']);
    }

  }



  loginMe() : void {
    
    this.securityService.authenticate(this.model).subscribe( data => {
  
    this.route.navigate(['home']);

    },err=>{
      this.errorMessage="Username or Password is Incorrect";
    }  
  );
  }
   
    
  
 

}
