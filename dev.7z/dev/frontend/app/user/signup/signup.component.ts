import { Component, OnInit } from '@angular/core';

import { User } from '../../user.model';

import { SecurityService } from '../../services/security.service';
import { error } from 'util';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  model = new User();
  
  errorMessage : string = null;

  successMessage : string = null;
  
  constructor(private securityService : SecurityService, private route : Router) { }

  ngOnInit() {
  }

  signup() : void
  {
    this.securityService.signup(this.model).then(() => {
      this.route.navigate(['signup'] );
      this.successMessage = "You have been registered. please login to continue...";
    });  
    
  }

}
