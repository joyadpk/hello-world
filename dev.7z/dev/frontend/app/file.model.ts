
export class file{
    public fileName : string;
    public user : string;
    public defectId : string;
    public uploadId : string;
}