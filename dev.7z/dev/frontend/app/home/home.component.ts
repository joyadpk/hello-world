import { Component, OnInit } from '@angular/core';

import {DefectService} from '../services/defect.service';
 
import { Defect } from '../defect.model';
import { SecurityService } from '../services/security.service';

import { User } from '../user.model';
import { Router } from '@angular/router';

import {AlertService} from '../services/alert.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css', '../app.component.css']
})
export class HomeComponent implements OnInit {
  isLoading = false;
  home : Array<Defect> = []; 

  currentUser: User;

  // Table settings
  settings = {
    columns: {
      defect_subject: {
        title : 'Subject'
      },
      defect_application: {
        title: 'Application'
      },
      defect_service: {
        title: 'Service'
      },
      defect_author: {
        title: 'Author'
      }
    },
    actions : {
      add: false,
      edit: false,
      delete: false
    },
    pager : {
      perPage: 5
    }
  };

  constructor(private alertService: AlertService,private defectService: DefectService, private securityService: SecurityService, private route:Router) {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));

  }

  /*
  getDefects() : void {
    this.defectService.getAllDefects().then((defect) => {
    this.defect = defect,
    this.isLoading= false;
    });  
  }

  */

  getLatestData() {

    this.defectService.getLatestDefects().then((defect) => {
      this.home = defect,
      this.isLoading= false;
      });  
  }


  ngOnInit() { 
    if(this.currentUser != null)
  {
    this.getLatestData();
  } 
      
  }


  logOut() {
    this.securityService.logOut()
      .subscribe(
        data => {
          this.route.navigate(['/login']);
        },
        error => {

        });
  }















// Chart 1 Details


public chartType1:string = 'bar';

public chartDatasets1:Array<any> = [
{data: [65, 59, 80, 81, 56, 55, 40], label: 'My First dataset'},
{data: [28, 48, 40, 19, 86, 27, 90], label: 'My Second dataset'}
];

public chartLabels1:Array<any> = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'];

public chartColors1:Array<any> = [
{
    backgroundColor: 'rgba(220,220,220,0.2)',
    borderColor: 'rgba(220,220,220,1)',
    borderWidth: 2,
    pointBackgroundColor: 'rgba(220,220,220,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(220,220,220,1)'
},
{
    backgroundColor: 'rgba(151,187,205,0.2)',
    borderColor: 'rgba(151,187,205,1)',
    borderWidth: 2,
    pointBackgroundColor: 'rgba(151,187,205,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(151,187,205,1)'
}
];

public chartOptions1:any = { 
responsive1: true
};

public chartClicked1(e: any): void { 
 
} 

public chartHovered1(e: any): void {
 
}




// Chart 2 Details 


public chartType2:string = 'pie';

public chartData2:Array<any> = [300, 50, 100, 40, 120];

public chartLabels2:Array<any> = ['Red', 'Green', 'Yellow', 'Grey', 'Dark Grey'];

public chartColors2:Array<any> = [{
hoverBorderColor: ['rgba(0, 0, 0, 0.1)', 'rgba(0, 0, 0, 0.1)', 'rgba(0, 0, 0, 0.1)', 'rgba(0, 0, 0, 0.1)', 'rgba(0, 0, 0, 0.1)'], 
hoverBorderWidth: 0, 
backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"], 
hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5","#616774"]
}];

public chartOptions2:any = { 
responsive: true
};

public chartClicked2(e: any): void { 
 
} 

public chartHovered2(e: any): void { 
 
}









}










