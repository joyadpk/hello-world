import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from '../home/home.component';
import { CreateComponent } from '../create/create.component';
import { SearchComponent} from '../search/search.component';
import { SearchResultComponent } from '../search/search-result/search-result.component';

import { UserComponent } from '../user/user.component';
import { LoginComponent }  from '../user/login/login.component';
import { SignupComponent } from '../user/signup/signup.component';

import { UrlPermission } from '../url.permission';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent, canActivate: [UrlPermission]
  },
  {
    path: 'create',
    component: CreateComponent, canActivate: [UrlPermission]
  },
  {
    path: 'search',
    component: SearchComponent, canActivate: [UrlPermission]
  },
   {
    path: 'searchRslt/:id',
   component: SearchResultComponent, canActivate: [UrlPermission]
   },

   {
     path : 'login',
     component : UserComponent,
     children : [{ path : '', component : LoginComponent }]
   },

   {
    path : 'signup',
    component : UserComponent,
    children : [{ path : '', component : SignupComponent }]
  },

 
  {
  //  path: '**',
  path : '',
  redirectTo: 'login',
  pathMatch : 'full'
  }
];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule {}
