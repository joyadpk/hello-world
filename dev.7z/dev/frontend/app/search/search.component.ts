import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

import { Defect } from '../defect.model';

import { DefectService } from '../services/defect.service';

import { Router } from '@angular/router';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css', '../app.component.css']
})
export class SearchComponent implements OnInit {


  isLoading = true;
  defect : Array<Defect> = []; 

  // Table settings
  settings = {
    columns: {
      defect_subject: {
        title : 'Subject'
      },
      defect_application: {
        title: 'Application'
      },
      defect_service: {
        title: 'Service'
      },
      defect_author: {
        title: 'Author'
      }
    },
    actions : {
      add: false,
      edit: false,
      delete: false
    },
    pager : {
      perPage: 5
    },
  };

  select(value) {
    this.route.navigate(['searchRslt' ,value.data.id] )//.Id,
    }

  constructor(private defectService: DefectService, private route: Router) {}
  
  getDefects() : void {
    this.defectService.getAllDefects().then((defect) => {
    this.defect = defect,
    this.isLoading= false;
    });  
  }

    ngOnInit() {
      this.getDefects(); 
    }













































//  @ViewChild('keywordInput') keywordInputRef: ElementRef;
//  @ViewChild('applInput') applInputRef: ElementRef;
//  @ViewChild('srvcInput') srvcInputRef: ElementRef;
  
//  searchClicked = false;
//  isLoading = true;
// applications: Array<String> = [];
//  services: Array<String> = [];
//  searchResult: Array<Defect> = [];
/*  searchParam  = {
    'keyword': '',
    'application': '',
    'service': ''

  };
*/
  // applications: Array<String> = ['1', '2', '3'];
  // services: Array<String> = ['S1', 'S2', 'S3', 'S4'];


 /*
  initSearch() {
    this.isLoading = true;
    this.searchClicked = true;
    this.searchParam.keyword = this.keywordInputRef.nativeElement.value;
    this.searchParam.application = this.applInputRef.nativeElement.value;
    this.searchParam.service = this.srvcInputRef.nativeElement.value;

    this.searchService
      .getSearchResult(this.searchParam).subscribe(
        data => (this.searchResult = data),
        error => console.log(error),
        () => (this.isLoading = false)
      );
  }

*/  

/*
  getData() {
    this.isLoading = false;
  }
*/

}
