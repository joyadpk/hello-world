import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

import { ActivatedRoute } from '@angular/router';

import { DefectService } from '../../services/defect.service';

import { Defect } from '../../defect.model';
import { Apps } from '../../model/app-list';
import { Services } from '../../model/service-lists';
import { User } from '../../user.model';
import { file } from '../../file.model';

import { Router } from '@angular/router';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['../../app.component.css', './search-result.component.css']
})
export class SearchResultComponent implements OnInit {
  
  /*
  settings = {
    columns: {
      defect_application: {
        title: 'Application'
      },
      defect_service: {
        title: 'Service'
      },
      defect_subject: {
        title: 'Subject'
      },
      defect_resolution: {
        title: 'Resolution'
      },
      defect_author: {
        title: 'Author'
      }
    },
    actions: {
      add: false,
      edit: false,
      delete: false
    },
    pager: {
      perPage: 5
    }
  };

*/
  isLoading : boolean = true;
  defect = new Defect();
  id: string;
  private sub: any;
  applications = Apps;
  services = Services;
  currentUser : User;

  uploadData = new file();

  constructor(private defectService: DefectService,private route: ActivatedRoute, private router : Router) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = params['id']; 
      this.getData();
      this.getUploads();
   });
  }


getData() {
    this.defectService.getDefectById(this.id).then((defect) => {
      this.defect = defect;
      this.isLoading= false;
  });
  }

  getUploads()
  {
    this.defectService.getUploads(this.id).then((fileData) => {
      this.uploadData = fileData;
    });
  }

  condition() : boolean
  {
    if(this.currentUser.username == this.defect.defect_author)
    {
      return false;
    }

    else{
      return true;
    }
  }

  updateDoc()
  {
    this.isLoading =  true;

    this.defectService.updateDefect(this.defect.id, this.defect).then((defect) => {
      this.defect = defect;
      this.isLoading= false;
      this.router.navigate(['searchRslt' ,this.defect.id] );
  });
  }

  download(u :file)
  {
   let id : string = u.uploadId;
   console.log(id);
   this.defectService.downloadFile(id);
  }

}
