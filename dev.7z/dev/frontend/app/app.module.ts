import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

// This is to inject the routing module to app module
import { AppRoutingModule } from './app-routing/app-routing.module';

import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { HomeComponent } from './home/home.component';
import { CreateComponent } from './create/create.component';
import { SearchComponent } from './search/search.component';

import { SearchResultComponent } from './search/search-result/search-result.component';

import { LoadingComponent } from './shared/loading/loading.component';

import { MDBBootstrapModule } from 'angular-bootstrap-md';

// Smart table
//import { Ng2SmartTableModule } from 'ng2-smart-table';

import { DefectService } from './services/defect.service';

import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { BsDatepickerModule } from 'ngx-bootstrap';

import { Ng2SmartTableModule } from 'ng2-smart-table-extended';
import { LoginComponent } from './user/login/login.component';

//import { CustomEditorComponent } from './custom-editor.component';

//import { XhrInterceptor } from './app.interceptor';
import { UserComponent } from './user/user.component';
import { SignupComponent } from './user/signup/signup.component';
//import { HTTP_INTERCEPTORS } from '@angular/common/http/';

import { SecurityService } from '../app/services/security.service'; 

import {UrlPermission} from "./url.permission";
import { NavbarComponent } from './navbar/navbar.component';

import { FileDropDirective } from 'ng2-file-upload';

import { ReactiveFormsModule } from '@angular/forms';
import { AlertService } from './services/alert.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    CreateComponent,
    SearchComponent,
    SearchResultComponent,
    LoadingComponent,
    LoginComponent,
    UserComponent,
    SignupComponent,
    NavbarComponent,
    FileDropDirective
  ],
 // entryComponents: [CustomEditorComponent, CustomRenderComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    Ng2SmartTableModule,
    MDBBootstrapModule.forRoot(),
    TooltipModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ReactiveFormsModule

  ],
  schemas: [ NO_ERRORS_SCHEMA ],
  providers: [DefectService, SecurityService, UrlPermission, AlertService /*, { provide: HTTP_INTERCEPTORS, useClass: XhrInterceptor, multi: true }*/],
  bootstrap: [AppComponent]
})
export class AppModule { }
