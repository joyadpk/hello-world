package com.mphasis.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mphasis.model.FileBucket;



public interface FileBucketDao extends MongoRepository<FileBucket, String>{

	List<FileBucket> findByDefectId(String id);
	
	
	
	
}
