package com.mphasis.controller;
import org.springframework.data.mongodb.core.query.Criteria;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import com.mphasis.dao.DefectRepository;
import com.mphasis.dao.FileBucketDao;
import com.mphasis.dao.UserRepository;
import com.mphasis.exception.CustomErrorType;
import com.mphasis.model.FileBucket;
import com.mphasis.model.User;

@RestController
@CrossOrigin("*")
public class UserController {

	@Autowired
	UserRepository userdao;
	
	@Autowired
	DefectRepository defectdao;
	
	@Autowired
	FileBucketDao filedao;
	
	// to encrypt the password
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	GridFsOperations gridOperations;
	
	
	// sign up a new user
	
	 @PostMapping("/signup")
	    public void signUp(@RequestBody User user) {
		// System.out.println(user.getUsername()+user.getPassword());
	        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
	        user.setState("active");
	        user.setRole("USER");
	      //  System.out.println("Encrypted Password : "+user.getPassword());
	        userdao.save(user);

	    }
	
	 
	 
	 // sign in a user
	 

	 @GetMapping(value = "/login")
	 public Principal user(Principal principal) 
	 {
		 //System.out.println("Aaya kya "+principal);
			return principal;
	 }
	 
	 
	 // upload file / files
	 
	 @PostMapping(value = "/upload/{id}/{username}")
	 public void uploadFiles(@PathVariable("id") String id, @PathVariable("username") String username, @RequestBody MultipartFile file )
	 throws IOException{
		 
		 File f = new File(file.getOriginalFilename());
		 
		 f.createNewFile();
		 
		 FileOutputStream fos = new FileOutputStream(f); 
		 
		 fos.write(file.getBytes());
		 
		 
		 DBObject metaData = new BasicDBObject();
			
		 metaData.put("organization", "mphasis");
		 
		 InputStream inputStream = new FileInputStream(f); 
		 

		 // Store file to MongoDB

		 String uploadId = gridOperations.store(inputStream,file.getOriginalFilename(), metaData).getId().toString();
		 
		 
		 FileBucket f1 = new FileBucket();
		 
		 f1.setFileName(file.getOriginalFilename());
		 f1.setUploadId(uploadId);
		 f1.setDefectId(id);
		 f1.setUser(username);

		 filedao.save(f1);
		 
	 }
	 
	 
	 
	 @GetMapping(value = "/docs/{id}", produces=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<List<FileBucket>> getDocs(@PathVariable("id") String id)
	 {
		 List<FileBucket> bucket = new ArrayList<FileBucket>();
		 
		 bucket = filedao.findByDefectId(id);
		 
		 return new ResponseEntity<List<FileBucket>>(bucket, HttpStatus.OK);
	 }
	 
	 
	 
	 @GetMapping(value = "/download/{id}")
		public ResponseEntity<InputStreamResource> retrieveImageFile(@PathVariable("id") String id1) throws IOException{
		
			GridFSDBFile file = gridOperations.findOne(new Query(Criteria.where("_id").is(id1)));
			
			System.out.println("download hui kya "+file.getFilename());

			 return ResponseEntity
			            .ok().header("Content-Disposition", "attachment;filename="+file.getFilename())
			            .contentLength(file.getLength())
			            .contentType(
			                    MediaType.parseMediaType("application/octet-stream"))
			            .body(new InputStreamResource(file.getInputStream()));
			
						}
	 
	 
	 
	 
	
}
