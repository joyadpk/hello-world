package com.mphasis.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="defect")
public class Defect {
	
	private String id;
	
	private String defect_application;
	
	private String defect_service;
	
	private String defect_date;
	
	private String defect_author;
	
	private String defect_subject;
	
	private String defect_resolution;
	
	public Defect() {
		
	}
	
	public Defect(String id,String defect_application, String defect_service, String defect_date,
			String defect_author, String defect_subject, String defect_resolution) {
		super();
		this.id = id;
		this.defect_application = defect_application;
		this.defect_service = defect_service;
		this.defect_date = defect_date;
		this.defect_author = defect_author;
		this.defect_subject = defect_subject;
		this.defect_resolution = defect_resolution;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDefect_subject() {
		return defect_subject;
	}

	public void setDefect_subject(String defect_subject) {
		this.defect_subject = defect_subject;
	}

	public String getDefect_application() {
		return defect_application;
	}

	public void setDefect_application(String defect_application) {
		this.defect_application = defect_application;
	}

	public String getDefect_service() {
		return defect_service;
	}

	public void setDefect_service(String defect_service) {
		this.defect_service = defect_service;
	}

	public String getDefect_date() {
		return defect_date;
	}

	public void setDefect_date(String defect_date) {
		this.defect_date = defect_date;
	}

	public String getDefect_author() {
		return defect_author;
	}

	public void setDefect_author(String defect_author) {
		this.defect_author = defect_author;
	}

	public String getDefect_resolution() {
		return defect_resolution;
	}

	public void setDefect_resolution(String defect_resolution) {
		this.defect_resolution = defect_resolution;
	}

	@Override
	public String toString() {
		return "Defect [id=" + id + ", defect_application=" + defect_application + ", defect_service=" + defect_service
				+ ", defect_date=" + defect_date + ", defect_author=" + defect_author + ", defect_subject="
				+ defect_subject + ", defect_resolution=" + defect_resolution + "]";
	}

}
