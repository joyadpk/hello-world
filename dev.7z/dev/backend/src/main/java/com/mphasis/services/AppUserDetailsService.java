package com.mphasis.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mphasis.dao.UserRepository;
import com.mphasis.model.User;

@Service
public class AppUserDetailsService implements UserDetailsService {

		@Autowired
		UserRepository dao;

		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			User user = dao.findByUsername(username);
			System.out.println("User : "+user);
			
			
			return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), 
	                 user.getState().equals("active"), true, true, true, getGrantedAuthorities(user));
			
		}
		
		
		private List<GrantedAuthority> getGrantedAuthorities(User user)
		{
	        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
	         
	        authorities.add(new SimpleGrantedAuthority(user.getRole()));
	  
	        return authorities;
	    }
		
}
