package com.mphasis.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;

import com.mphasis.model.Defect;

@Repository
public interface DefectRepository extends MongoRepository<Defect, String>{


	Defect findOne(String id);
	
	List<Defect> findAll();
	
	boolean exists(String id);
	
	//List<Defect>findById(String id);
	
	
}
