package com.mphasis.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import com.mphasis.dao.DefectRepository;
import com.mphasis.exception.CustomErrorType;
import com.mphasis.model.Defect;
import com.mphasis.services.AppUserDetailsService;
import org.springframework.data.domain.Sort.Order;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.http.MediaType;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;


@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class DefectController {

	@Autowired
	DefectRepository dao;
	
	
	
	// Get All Defect Documents
	
	
	@GetMapping(value = "/defect/all", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findAll()
	{
		if(dao.findAll().isEmpty())
		{
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		else
		{
		List<Defect> d = new ArrayList<Defect>();
		d = dao.findAll();
		return new ResponseEntity<List<Defect>>(d, HttpStatus.OK);
		}
		
	}
	
	// Get One Defect Document by Id
	
	@GetMapping(value = "/defect/findById/{id}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findOneById(@PathVariable("id") String id) 
	{
		if(dao.exists(id))
		{
			return new ResponseEntity<Defect> (dao.findOne(id), HttpStatus.OK);	
		}
		
		else
		{
			return new ResponseEntity(new CustomErrorType("Not Found"), HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	
	// Create a New Defect Document
	
	@PostMapping("/defect/create")
	public void createDefect(@RequestBody Defect d, UriComponentsBuilder ucBuilder)
	{
		/*if (dao.exists(d.getId()))
		{
            return new ResponseEntity(new CustomErrorType("Unable to create, already exist."),HttpStatus.CONFLICT);
        }*/
        dao.save(d);
		
	}
	
	
	// Delete a Defect Document by Id
	
	@DeleteMapping("/defect/delete/{id}")
	public ResponseEntity<?> deleteById(@PathVariable("id") String id, UriComponentsBuilder ucBuilder)
	{
		if(dao.exists(id))
		{
			dao.delete(id);
			
			HttpHeaders headers = new HttpHeaders();
	        headers.setLocation(ucBuilder.path("/api/defect/findById/{id}").buildAndExpand(id).toUri());
	        return new ResponseEntity<String>(headers, HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity(new CustomErrorType("Does Not Exist In The Database"), HttpStatus.CONFLICT);
		
	}

	
	// Update a Defect Document By Id
	
	@PutMapping("/defect/update/{id}")
	public ResponseEntity<?> updateById(@PathVariable("id") String id, @RequestBody Defect newDefect, UriComponentsBuilder ucBuilder)
	{
		Defect defect = dao.findOne(id);
		
		if(defect == null)
		{
			return new ResponseEntity(new CustomErrorType("The Document Does Not Exist In the Databse"),HttpStatus.NOT_FOUND);
		}
		
		
		defect.setDefect_application(newDefect.getDefect_application());
		defect.setDefect_author(newDefect.getDefect_author());
		defect.setDefect_date(newDefect.getDefect_date());
		defect.setDefect_resolution(newDefect.getDefect_resolution());
		defect.setDefect_service(newDefect.getDefect_service());
		defect.setDefect_subject(newDefect.getDefect_subject());
		
		Defect updatedDefect = dao.save(defect);
		
		return new ResponseEntity<Defect>(updatedDefect, HttpStatus.OK);
		
		
	}
	
	@Autowired
	MongoOperations mo;
	
	// Get Latest Defect Documents from database
	
	
	@GetMapping(value = "/defect/latest", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> findLatest()
	{
		
		List<Defect> d = new ArrayList<Defect>();
		
		Query query = new Query();
		
		query.with(new Sort(new Order(Direction.DESC, "defect_date")));
		
		query.limit(5);
		
		d = mo.find(query, Defect.class);
		
		return new ResponseEntity<List<Defect>>(d, HttpStatus.OK);
		
	}
	
	
	
	 
	 
	 // Spring Security implementation
	 
	 
	
	 
	 @Configuration
	  protected static class SecurityConfiguration extends WebSecurityConfigurerAdapter {
		 
		 
		 @Autowired
		AppUserDetailsService appUserDetailsService;
		 
		 
		 @Bean
		    public PasswordEncoder passwordEncoder() {
		        return new BCryptPasswordEncoder();
		    }
		 
		 @Bean
		    public DaoAuthenticationProvider authenticationProvider() {
		        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
		        authenticationProvider.setUserDetailsService(appUserDetailsService);
		        authenticationProvider.setPasswordEncoder(passwordEncoder());
		        return authenticationProvider;
		    }
		 
		 
		 
		 @Override
			protected void configure(AuthenticationManagerBuilder auth) throws Exception {
				auth.userDetailsService(appUserDetailsService);
				auth.authenticationProvider(authenticationProvider());
			}
		 
		 
		 @Bean
			public WebMvcConfigurer corsConfigurer() {
			    return new WebMvcConfigurerAdapter() {
			        @Override
			        public void addCorsMappings(CorsRegistry registry) 
			        {
			            registry.addMapping("/**").allowedOrigins("http://localhost:4200");
			        }
			    };
		 }
		 
		 
		 
	    @Override
	    protected void configure(HttpSecurity http) throws Exception {
	      http
	          .cors().and()
	     //   
	          .authorizeRequests()
	          .antMatchers("/signup","/logout").permitAll()
	          .antMatchers("/api/defect/**").permitAll().and()	          
	
//	          .anyRequest().authenticated().and()
	          
	          .logout()
	          .permitAll()
	  		  .logoutRequestMatcher(new AntPathRequestMatcher("/logout", "POST")).and()
	          
	          .httpBasic().and()
	          .sessionManagement().disable()
	        //  .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and()
	          .csrf().disable();        
	         
	    }
	  }
	 
	 
	 
	
}
