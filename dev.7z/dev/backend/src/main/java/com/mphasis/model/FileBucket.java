package com.mphasis.model;


import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.multipart.MultipartFile;

@Document(collection="uploads")
public class FileBucket {
	
	private String fileName;
	 
	private String defectId;
    
	private String user; 
	
	private String uploadId;
 

	public FileBucket()
	{
		
	}
	

	public String getUploadId() {
		return uploadId;
	}


	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}


	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	 public String getUser() {
			return user;
		}

	public void setUser(String user) {
		this.user = user;
	}


	public String getDefectId() {
		return defectId;
	}

	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}

	
	public FileBucket(String fileName, String defectId, String user, String uploadId) {
		super();
		this.fileName = fileName;
		this.defectId = defectId;
		this.user = user;
		this.uploadId = uploadId;
	}

	@Override
	public String toString() {
		return "FileBucket [fileName=" + fileName + ", defectId=" + defectId + ", user=" + user + ", uploadId="
				+ uploadId + "]";
	}	
	
}